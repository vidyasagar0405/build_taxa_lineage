# build_taxa_lineage

[![PyPI - Version](https://img.shields.io/pypi/v/build-taxa-lineage.svg)](https://pypi.org/project/build-taxa-lineage)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/build-taxa-lineage.svg)](https://pypi.org/project/build-taxa-lineage)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install build-taxa-lineage
```

## License

`build-taxa-lineage` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
