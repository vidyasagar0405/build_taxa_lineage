# build_taxa_lineage

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install git+https://github.com/vidyasagar0405/build_taxa_lineage.git#egg=build_taxa_lineage
```

## License

`build-taxa-lineage` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
